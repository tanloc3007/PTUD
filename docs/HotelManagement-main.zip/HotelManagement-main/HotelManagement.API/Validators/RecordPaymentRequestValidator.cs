using FluentValidation;
using HotelManagement.API.Controllers;

namespace HotelManagement.API.Validators;

public class RecordPaymentRequestValidator : AbstractValidator<RecordPaymentRequest>
{
    public RecordPaymentRequestValidator()
    {
        RuleFor(x => x)
            .Must(x => x.BookingId.HasValue ^ x.InvoiceId.HasValue)
            .WithMessage("Thanh to�n ph?i g?n ��ng m?t trong hai �?i t�?ng: booking ho?c h�a ��n.");

        When(x => x.BookingId.HasValue, () =>
        {
            RuleFor(x => x.BookingId)
                .GreaterThan(0).WithMessage("Booking kh�ng h?p l?.");
        });

        When(x => x.InvoiceId.HasValue, () =>
        {
            RuleFor(x => x.InvoiceId)
                .GreaterThan(0).WithMessage("H�a ��n kh�ng h?p l?.");
        });

        RuleFor(x => x.AmountPaid)
            .GreaterThan(0).WithMessage("S? ti?n thanh to�n ph?i l?n h�n 0.");

        RuleFor(x => x.PaymentType)
            .MaximumLength(50).WithMessage("Lo?i thanh to�n t?i �a 50 k? t?.");

        RuleFor(x => x.PaymentMethod)
            .MaximumLength(50).WithMessage("Ph��ng th?c thanh to�n t?i �a 50 k? t?.");

        RuleFor(x => x.TransactionCode)
            .MaximumLength(100).WithMessage("M? giao d?ch t?i �a 100 k? t?.");
    }
}
